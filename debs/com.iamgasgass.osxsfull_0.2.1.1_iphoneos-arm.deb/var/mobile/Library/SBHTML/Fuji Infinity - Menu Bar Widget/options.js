var iphoneXmode = false; //Toggle iPhone X/XS mode
var darkmode = true; //Toggle darkmode
var twelvehour = false; // Toggle 12/24-hour clock
var backgroundBlur = false; //Toggle homescreen background blur
var blurradius = 15; //Background blur radius (in pixels)


var batterypercent = false; //Toggle battery percent
var batteryicon = true; //Toggle battery icon
var wifi = true; //Toggle wifi