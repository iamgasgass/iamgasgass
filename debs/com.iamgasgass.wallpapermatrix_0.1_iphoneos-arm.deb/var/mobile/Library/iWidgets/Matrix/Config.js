var Characters = "田由甲申甴电甶男甸甹町画甼甽甾甿畀畁畂畃畄畅畆畇畈畉畊畋界畍畎畏畐畑"; // used for animation
var TimeUpdate = 33; // ms
var FontSize = 17; // px
var DefaultCharacters = "田由甲申甴电甶男甸甹町画甼甽甾甿畀畁畂畃畄畅畆畇畈畉畊畋界畍畎畏畐畑"; // dont change, its if you want restore the default character (copy/paste in Characters)